library(shiny)
library(shinydashboard)
library(readxl)
library(DT)
library(dplyr)
library(ggplot2)
library(lubridate)
library(fpp2)
library(tidyverse)
library(bbplot)
require(gridExtra)

data <- read_excel("data/MicrofinanceData.xlsx")

months <- unique(month(data$As_of_Date))
month.names <- month.names <- c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")

ui <- dashboardPage(
  dashboardHeader(title = "Business Dashboard"),
  dashboardSidebar(
    sidebarMenu(
      tags$br(),
      selectInput("inBranch", "Select Branch", choices = data$Branch_name, selected = 1),
      selectInput("year", "Select Year", choices = unique(year(data$As_of_Date)), selected = 1),
      selectInput("month", "Select Month", choices = month.names, selected = 1),
      sliderInput("n", "Number of Data", 1, 15, c(1, 15)),
      sliderInput("bins", "Number of Breaks", 1, 100, 50),
      tags$br()
    )
  ),
  
  dashboardBody(
    tags$head(tags$style(HTML('.main-header .logo {
        font-weight: bold;
        font-size: 20px;
      }'
    ))),
    fluidPage(
      fluidRow(
        column(width = 2,
          valueBoxOutput("Box1", width = NULL),
          valueBoxOutput("Box2", width = NULL),
          valueBoxOutput("Box3", width = NULL),
        ),
        column(width = 4,
               box(width=NULL, title = "Data Table", solidHeader = TRUE, status = "primary", dataTableOutput("dataTable"))
               ),
        column(width = 6,
               tabBox(width=NULL, title = "Time Series", id = "tabset4", 
                      tabPanel("Loan Portfolio", solidHeader = TRUE, plotOutput("inTS1")),
                      tabPanel("Borrowers", solidHeader = TRUE, plotOutput("inTS2")),
                      tabPanel("Members", solidHeader = TRUE, plotOutput("inTS3"))
               )
        )
      ),
      fluidRow(
        column(width = 12,
               tabBox(
                 width=NULL, title = "Scatter Plot", id = "tabset2",
                 tabPanel("Members & Dropout", solidHeader = TRUE, plotOutput("inBar1")),
                 tabPanel("Actual & Required Staffing", solidHeader = TRUE, plotOutput("inBar2")),
                 tabPanel("Loan Portfolio & PAR", solidHeader = TRUE, plotOutput("inBar3")),
                 tabPanel("Opened Branches & Target", solidHeader = TRUE, plotOutput("inBar4")),
               )
        )
      )
      )
    )
)

server <- function(input, output) {
  
  output$Box1 <- renderValueBox({
    data <- data %>%
      filter(year(As_of_Date) == input$year & month.names == input$month)
    
    data <- data[c("As_of_Date", "Loan_Amount")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    sum <- sum(data$Loan_Amount)
    valueBox(paste0(round(sum / 100000, 2), " M"), paste0("Gross Loan Portfolio as of ", input$month , " ", input$year), color = "light-blue")
  })
  
  output$Box2 <- renderValueBox({
    data <- data %>%
      filter(year(As_of_Date) == input$year & month.names == input$month)
    
    data <- data[c("As_of_Date", "PAR")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    sum <- sum(data$PAR)
    valueBox( paste0(round(sum / 100000, 2), " M"), paste0("Pension adjustment reversal (PAR) Grand Total as of  ", input$month , " ", input$year), color = "light-blue")
  })
  
  output$Box3 <- renderValueBox({
    data <- data %>%
      filter(year(As_of_Date) == input$year & month.names == input$month)
    
    data <- data[c("As_of_Date", "Members")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    sum <- sum(data$Members)
    valueBox( sum, paste0("Total Membership as of   ", input$month , " ", input$year), color = "light-blue")
  })
  
  output$dataTable <- DT::renderDataTable({
    filteredData <- data %>% # Generate filtered data in the table
      filter(year(As_of_Date) == input$year) %>%
      select(2, 8:22)
  }, options = list( # Customize table's appearance and behavior
    pageLength = 5,
    scrollX = TRUE
  ))
  
  output$inTS1 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Loan_Amount")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    p1 <- autoplot(ts(data[input$n[1]:input$n[2], "Loan_Amount"])) +
      ggtitle(paste0("Loan Profile of ", input$inBranch, " Branch"))
    
    grid.arrange(p1, ncol=1)
  })
  
  output$inTS2 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Borrowers")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    p1 <- autoplot(ts(data[input$n[1]:input$n[2], "Borrowers"])) +
      ggtitle(paste0("Borrowers Amount at ", input$inBranch, " Branch"))
    
    grid.arrange(p1, ncol=1)
  })
  
  output$inTS3 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Members")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    p1 <- autoplot(ts(data[input$n[1]:input$n[2], "Members"])) +
      ggtitle(paste0("Total Members at ", input$inBranch, " Branch"))
    
    grid.arrange(p1, ncol=1)
  })
  
  output$inBar1 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Members", "Drop_out")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    ggplot(data, 
           aes(x = As_of_Date, y = Drop_out)) +
      geom_point(aes(color = Members),
                 size = 2, 
                 alpha=.6) +
      geom_smooth(size = 1.5,
                  color = "darkgrey") +
      scale_x_continuous(breaks = input$bins) + 
      labs(x = "Date",
           y = "Drop_out",
           title = paste0("Total Members and Drop Out by Date (", input$inBranch, " Branch)")) +
      theme_minimal()+
      bbc_style()
  })
  
  output$inBar2 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Staff", "Staff_required")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    ggplot(data, 
           aes(x = As_of_Date, y = Staff_required)) +
      geom_point(aes(color = Staff),
                 size = 2, 
                 alpha=.6) +
      geom_smooth(size = 1.5,
                  color = "darkgrey") +
      scale_x_continuous(breaks = input$bins) + 
      labs(x = "Date",
           y = "Staff Required",
           title = paste0("Total Staff and Required Staff by Date (", input$inBranch, " Branch)")) +
      theme_minimal()+
      bbc_style()
  })
  
  output$inBar3 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "PAR", "Loan_Amount")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    ggplot(data, 
           aes(x = As_of_Date, y = Loan_Amount)) +
      geom_point(aes(color = PAR),
                 size = 2, 
                 alpha=.6) +
      geom_smooth(size = 1.5,
                  color = "darkgrey") +
      scale_x_continuous(breaks = input$bins) + 
      labs(x = "Date",
           y = "Loan Amount",
           title = paste0("Total Loan and Par by Date (", input$inBranch, " Branch)")) +
      theme_minimal()+
      bbc_style()
  })
  
  output$inBar4 <- renderPlot({
    data <- data %>%
      filter(Branch_name == input$inBranch)
    
    data <- data[c("As_of_Date", "Opened_Branches", "Target")]
    data$As_of_Date <- as.Date(data$As_of_Date)
    
    ggplot(data, 
           aes(x = As_of_Date, y = Opened_Branches)) +
      geom_point(aes(color = Target),
                 size = 2, 
                 alpha=.6) +
      geom_smooth(size = 1.5,
                  color = "darkgrey") +
      scale_x_continuous(breaks = input$bins) + 
      labs(x = "Date",
           y = "Opened Branches",
           title = paste0("Opened Branches and Target by Branch (", input$inBranch, " )")) +
      theme_minimal()+
      bbc_style()
  })
  
}

shinyApp(ui = ui, server = server)